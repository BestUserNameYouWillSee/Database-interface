# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.
import pymysql

sAnswer = input("What do you want to do?\n 1. add\n 2. delete\n 3. update\n 4. show\n> ").lower()

if sAnswer == "add":

    # database connection
    connection = pymysql.connect(host="localhost", user="root", password="", database="filmdatabase")
    cursor = connection.cursor()
    # some other statements  with the help of cursor
    s_table = input("Choose table:\n 1. acteur\n 2. crew\n 3. film\n 4. filmcast\n 5. filmcrew\n 6. productiehuis")

    if s_table == "acteur":
        s_firstname = input("FirstName:")
        s_lastname = input("LastName:")
        s_gender = input("Gender:")
        date_birthdate = input("Birthdate:")
        s_residence = input("Residence:")
        s_country = input("Country:")
        s_specialty = input("Specialty:")
        cursor.execute("INSERT INTO acteur(Voornaam, Achternaam, Geslacht, Geboortedatum, Woonplaats, Land, Specialisme)"
                       " VALUES(""%s, %s, %s, %s, %s, %s, %s) ", (s_firstname, s_lastname, s_gender, date_birthdate, s_residence,
                                                          s_country, s_specialty))

    elif s_table == "crew":
        s_firstname = input("FirstName:")
        s_lastname = input("LastName:")
        s_gender = input("Gender:")
        date_birthdate = input("Birthdate:")
        s_residence = input("Residence:")
        s_country = input("Country:")
        s_specialty = input("Specialty:")
        cursor.execute(
            "INSERT INTO crew(Voornaam, Achternaam, Geslacht, Geboortedatum, Woonplaats, Land, Specialisme)"
            " VALUES(""%s, %s, %s, %s, %s, %s, %s) ", (s_firstname, s_lastname, s_gender, date_birthdate, s_residence,
                                                       s_country, s_specialty))

    elif s_table == "film":
        s_filmtitle = input("Title:")
        s_release_date = input("Release Date:")
        s_summary = input("Summary:")
        i_rating = input("Rating:")
        i_productionhouse_id = input("ProductionHouseID:")
        cursor.execute(
            "INSERT INTO film(Titel, Release_Date, Korte_inhoud, Rating, Productiehuis_ID)"
            " VALUES(""%s, %s, %s, %s, %s) ", (s_filmtitle, s_release_date, s_summary, i_rating, i_productionhouse_id))

    elif s_table == "filmcast":
        i_crewid = input("Crew ID")
        s_character = input("Character:")
        i_filmid = input("Film ID:")
        cursor.execute("INSERT INTO filmcast(CrewID, Personage, FilmID) VALUES(""%s, %s, %s) ", (i_crewid, s_character, i_filmid))

    elif s_table == "filmcrew":
        i_crewid = input("Crew ID")
        s_fucntion = input("Function:")
        i_filmid = input("Film ID:")
        cursor.execute("INSERT INTO filmcrew(CrewID, Functie, FilmID) VALUES(""%s, %s, %s) ",
                       (i_crewid, s_fucntion, i_filmid))
    elif s_table == "productiehuis":
        s_name = input("Name of productionhouse:")
        s_adres = input("Adres:")
        s_location = input("Location:")
        s_postalcode = input("Postalcode:")
        s_country = input("Country:")
        cursor.execute("INSERT INTO productiehuis(Naam, Adres, Plaats, Postcode, Land) VALUES(""%s, %s, %s, %s, %s) ",
                       (s_name, s_adres, s_location, s_postalcode, s_country))



    connection.commit()
    connection.close()
elif sAnswer == "delete":
    # database connection
    connection = pymysql.connect(host="localhost", user="root", password="", database="filmdatabase")
    cursor = connection.cursor()
    # some other statements  with the help of cursor
    s_table = input("Choose table:\n 1. acteur\n 2. crew\n 3. film\n 4. filmcast\n 5. filmcrew\n 6. productiehuis\n >")

    if s_table == "acteur":
        s_ActeurID = input("id:")

        cursor.execute("DELETE FROM acteur WHERE ActeurID = %s", s_ActeurID)

    elif s_table == "crew":
        s_crew = input("id:")

        cursor.execute("DELETE FROM crew WHERE CrewID = %s", s_crew)

    elif s_table == "film":
        s_film = input("id:")

        cursor.execute("DELETE FROM film WHERE FilmID = %s", s_film)

    elif s_table == "filmcast":
        s_filmcast = input("acteur id:")

        cursor.execute("DELETE FROM filmcast WHERE ActeurID = %s", s_filmcast)

    elif s_table == "filmcrew":
        s_filmcrew = input("Film id:")

        cursor.execute("DELETE FROM filmcrew WHERE FilmID = %s", s_filmcrew)

    elif s_table == "productiehuis":
        s_productiehuis = input("id:")

        cursor.execute("DELETE FROM productiehuis WHERE Productiehuis_ID = %s", s_productiehuis)


    connection.commit()
    connection.close()

elif sAnswer == "update":
    # database connection
    connection = pymysql.connect(host="localhost", user="root", password="", database="filmdatabase")
    cursor = connection.cursor()
    # some other statements  with the help of cursor

    # update 1 row
    sUpdate = input("what table do you want to update?\n >").lower()
    if sUpdate == "acteur":
        s_acteurid = input("ID:")
        s_firstname = input("FirstName:")
        s_lastname = input("LastName:")
        s_gender = input("Gender:")
        date_birthdate = input("Birthdate:")
        s_residence = input("Residence:")
        s_country = input("Country:")
        s_specialty = input("Specialty:")

        cursor.execute(
            "UPDATE acteur SET Voornaam= %s, Achternaam = %s, Geslacht = %s, Geboortedatum = %s, Woonplaats= %s, Land= %s"
            ", Specialisme= %s   WHERE ActeurID = %s", (s_firstname, s_lastname, s_gender, date_birthdate, s_residence,
                                                       s_country, s_specialty, s_acteurid))

    elif sUpdate == "crew":
        s_crewid = input("ID:")
        s_firstname = input("FirstName:")
        s_lastname = input("LastName:")
        s_gender = input("Gender:")
        date_birthdate = input("Birthdate:")
        s_residence = input("Residence:")
        s_country = input("Country:")
        s_specialty = input("Specialty:")

        cursor.execute(
            "UPDATE crew SET Voornaam= %s, Achternaam = %s, Geslacht = %s, Geboortedatum = %s, Woonplaats= %s, Land= %s"
            ", Specialisme= %s   WHERE CrewID = %s", (s_firstname, s_lastname, s_gender, date_birthdate, s_residence,
                                                        s_country, s_specialty, s_crewid))

    elif sUpdate == "film":
        i_filmID = input("ID:")
        s_filmtitle = input("Title:")
        s_release_date = input("Release Date:")
        s_summary = input("Summary:")
        i_rating = input("Rating:")
        i_productionhouse_id = input("ProductionHouseID:")
        cursor.execute(
            "UPDATE film SET Titel= %s, Release_Date = %s,  Korte_inhoud = %s, Rating = %s, Productiehuis_ID= %s,"
            ",    WHERE FilmID = %s", (s_filmtitle, s_release_date, s_summary,i_rating,i_productionhouse_id,))

    elif sUpdate == "filmcast":
        i_crewid = input("Crew ID:")
        s_character = input("Character:")
        i_filmid = input("Film ID:")
        cursor.execute(
            "UPDATE filmcast SET CrewID= %s, Personage = %s,  FilmID = %s,"
            ",    WHERE CrewID = %s", (i_crewid,s_character,i_filmid))

    elif sUpdate =="filmcrew":
        i_crewid = input("Crew ID:")
        s_fucntion = input("Function:")
        i_filmid = input("Film ID:")
        cursor.execute(
            "UPDATE filmcast SET CrewID= %s, Functie = %s,  FilmID = %s,"
            ",    WHERE CrewID = %s", (i_crewid, s_fucntion, i_filmid))

    elif sUpdate == "productiehuis":
        i_productiehuisid = input("ID:")
        s_name = input("Name of productionhouse:")
        s_adres = input("Adres:")
        s_location = input("Location:")
        s_postalcode = input("Postalcode:")
        s_country = input("Country:")
        cursor.execute(
            "UPDATE crew SET Naam= %s, Adres = %s, Plaats = %s, Postcode = %s, Land= %s,"
            ",   WHERE Productiehuis_ID = %s", (s_name,s_adres,s_location,s_postalcode,s_country,i_productiehuisid))

    connection.commit()
    connection.close()

elif sAnswer == "show":
    # database connection
    connection = pymysql.connect(host="localhost", user="root", password="", database="filmdatabase")
    cursor = connection.cursor()
    sShow = input("Choose table:\n 1. acteur\n 2. crew\n 3. film\n 4. filmcast\n 5. filmcrew\n 6. productiehuis\n >")

    if sShow == "acteur":
        cursor.execute(
            "SELECT * FROM acteur")
        for acteur in cursor:
            print(acteur)

    elif sShow == "crew":
        cursor.execute(
            "SELECT * FROM crew")
        for crew in cursor:
            print(crew)

    elif sShow == "film":
        cursor.execute(
            "SELECT * FROM film")
        for film in cursor:
            print(film)

    elif sShow == "filmcast":
        cursor.execute(
            "SELECT * FROM filmcast")
        for filmcast in cursor:
            print(filmcast)

    elif sShow == "filmcrew":
        cursor.execute(
            "SELECT * FROM filmcrew")
        for filmcrew in cursor:
            print(filmcrew)

    elif sShow == "productiehuis":
        cursor.execute(
            "SELECT * FROM productiehuis")
        for productiehuis in cursor:
            print(productiehuis)

    connection.commit()
    connection.close()